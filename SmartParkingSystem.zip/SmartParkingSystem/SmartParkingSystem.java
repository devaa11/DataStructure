import java.util.*;

public class SmartParkingSystem {

    // Define constants for maximum number of parking spots
    private static final int TOTAL_SPOTS = 10;

    // Parking slots (true = occupied, false = available)
    private static boolean[] parkingSpots = new boolean[TOTAL_SPOTS];

    // Map to store vehicle details (slot -> vehicle number)
    private static Map<Integer, String> vehicleMap = new HashMap<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        System.out.println("Welcome to the Smart Parking System (CLI Edition)");

        while (running) {
            System.out.println("\nMenu:");
            System.out.println("1. View Parking Status");
            System.out.println("2. Park a Vehicle");
            System.out.println("3. Remove a Vehicle");
            System.out.println("4. Find Nearest Available Spot");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    viewParkingStatus();
                    break;
                case 2:
                    parkVehicle(scanner);
                    break;
                case 3:
                    removeVehicle(scanner);
                    break;
                case 4:
                    findNearestSpot();
                    break;
                case 5:
                    running = false;
                    System.out.println("Exiting the system. Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }

    // Display the status of all parking spots
    private static void viewParkingStatus() {
        System.out.println("\nParking Status:");
        for (int i = 0; i < TOTAL_SPOTS; i++) {
            String status = parkingSpots[i] ? "Occupied" : "Available";
            System.out.println("Spot " + (i + 1) + ": " + status);
        }
    }

    // Park a vehicle in the nearest available spot
    private static void parkVehicle(Scanner scanner) {
        System.out.print("Enter vehicle number: ");
        String vehicleNumber = scanner.next();

        int spot = findNearestAvailableSpot();
        if (spot == -1) {
            System.out.println("No parking spots available.");
        } else {
            parkingSpots[spot] = true;
            vehicleMap.put(spot, vehicleNumber);
            System.out.println("Vehicle parked at spot " + (spot + 1) + ".");
        }
    }

    // Remove a vehicle from a parking spot
    private static void removeVehicle(Scanner scanner) {
        System.out.print("Enter spot number to remove vehicle from (1-" + TOTAL_SPOTS + "): ");
        int spot = scanner.nextInt() - 1;

        if (spot < 0 || spot >= TOTAL_SPOTS) {
            System.out.println("Invalid spot number.");
        } else if (!parkingSpots[spot]) {
            System.out.println("Spot " + (spot + 1) + " is already empty.");
        } else {
            parkingSpots[spot] = false;
            System.out.println("Vehicle " + vehicleMap.remove(spot) + " removed from spot " + (spot + 1) + ".");
        }
    }

    // Find the nearest available parking spot
    private static void findNearestSpot() {
        int spot = findNearestAvailableSpot();
        if (spot == -1) {
            System.out.println("No parking spots available.");
        } else {
            System.out.println("Nearest available spot: " + (spot + 1));
        }
    }

    // Helper function to find the nearest available parking spot
    private static int findNearestAvailableSpot() {
        for (int i = 0; i < TOTAL_SPOTS; i++) {
            if (!parkingSpots[i]) {
                return i;
            }
        }
        return -1; // No spots available
    }
}
